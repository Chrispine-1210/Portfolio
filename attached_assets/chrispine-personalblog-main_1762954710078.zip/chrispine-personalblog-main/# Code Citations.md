# Code Citations

## License: unknown
https://github.com/jw/zink/tree/e98486d1886e85ebe1b2ea87c8816a71619e77eb/elevenbits/templates/base.html

```
!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content=
```


## License: unknown
https://github.com/deltavi/deltavi.github.io/tree/307aa44535d96719fd3d465153f0824266394846/index.html

```
8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary
```


## License: unknown
https://github.com/VE-Design-Team/wtif-fssi/tree/79791af5a909ab276f5c57a66aa5c974742c8d08/EnablingTechnologies/Types%20of%20assistive%20technology/index905f.html

```
>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=
```


## License: unknown
https://github.com/calamarbisz/posenet/tree/19fefe80c90ba79e9a6f9883d351859fa47e4a66/index.html

```
UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!--
```


## License: unknown
https://github.com/AndryX-08/thestudyhub/tree/b45bba62d3b19bfaf94eaa9880e977bd851369b2/about.html

```
->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts
```

